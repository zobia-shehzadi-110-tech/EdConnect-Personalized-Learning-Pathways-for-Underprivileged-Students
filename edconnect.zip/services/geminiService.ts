import { GoogleGenAI, Type } from '@google/genai';
import { Language, LearningPathway, AssessmentQuestion, AssessmentAnswers, AnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const assessmentSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correct_option: { type: Type.STRING },
        },
        required: ['question', 'options', 'correct_option'],
    }
};

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        gapAnalysis: {
            type: Type.STRING,
            description: "A short, encouraging, 2-3 sentence summary of the student's main learning gaps, written directly to the student."
        },
        pathway: {
            type: Type.OBJECT,
            properties: {
                pathwayTitle: {
                    type: Type.STRING,
                    description: "A catchy and motivational title for the entire learning pathway."
                },
                steps: {
                    type: Type.ARRAY,
                    description: "A sequence of 3 logical learning steps to fix the identified gaps.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            step: { type: Type.NUMBER },
                            title: { type: Type.STRING },
                            description: { type: Type.STRING, description: "A one-sentence explanation of what this step will teach." },
                            type: { type: Type.STRING, enum: ['video', 'article', 'quiz', 'interactive'] },
                            link: { type: Type.STRING, description: "A real, valid, public URL for a free resource." }
                        },
                        required: ['step', 'title', 'description', 'type', 'link']
                    }
                }
            },
            required: ['pathwayTitle', 'steps']
        }
    },
    required: ['gapAnalysis', 'pathway']
};

export async function getDiagnosticAssessment(subject: string, language: Language): Promise<AssessmentQuestion[]> {
    const langInstruction = language === 'ur' ? 'Urdu' : 'English';
    const prompt = `
        You are an AI creating a diagnostic quiz for a student in rural Pakistan.
        Subject: ${subject.replace(/_/g, ' ')}
        Task: Create a simple 4-question multiple-choice quiz to test foundational knowledge on this subject. Each question should have 4 options. Ensure one option is clearly correct. The entire response, including questions and options, MUST be in the ${langInstruction} language.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: assessmentSchema,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as AssessmentQuestion[];
    } catch (error) {
        console.error('Error fetching assessment from Gemini API:', error);
        throw new Error('Failed to generate assessment.');
    }
}

export async function getGapAnalysisAndPathway(subject: string, questions: AssessmentQuestion[], answers: AssessmentAnswers, language: Language): Promise<AnalysisResult> {
    const langInstruction = language === 'ur' ? 'Urdu' : 'English';

    const assessmentReview = questions.map((q, index) => {
        const studentAnswer = answers[index];
        const isCorrect = studentAnswer === q.correct_option;
        return `Question ${index + 1}: "${q.question}"\nCorrect Answer: "${q.correct_option}"\nStudent's Answer: "${studentAnswer}" (${isCorrect ? 'Correct' : 'Incorrect'})`;
    }).join('\n\n');

    const prompt = `
        You are 'EdConnect', an expert AI tutor for underprivileged students. Your tone is encouraging and simple.

        A student took a quiz on the subject: "${subject.replace(/_/g, ' ')}". Here are their results:
        ${assessmentReview}

        Task:
        1.  Analyze the INCORRECT answers to identify the student's key learning gaps.
        2.  Write a short, encouraging 2-3 sentence summary of these gaps directly to the student.
        3.  Create a personalized 3-step learning pathway to help the student fix these specific gaps.
        4.  For each step, find one high-quality, FREE, and publicly accessible resource (like from Khan Academy, Wikipedia, YouTube, etc.). You MUST provide a real, working URL.
        5.  The entire response (gap analysis, titles, descriptions) MUST be in the ${langInstruction} language.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: analysisSchema,
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as AnalysisResult;

    } catch (error) {
        console.error('Error fetching pathway from Gemini API:', error);
        throw new Error('Failed to generate learning pathway.');
    }
}