import React from 'react';
import { AnalysisResult, Language } from '../types';
import { LOCALIZED_STRINGS } from '../constants';
import PathwayStepCard from './LearningStepCard';

interface PathwayDisplayProps {
  result: AnalysisResult;
  onReset: () => void;
  language: Language;
}

const PathwayDisplay: React.FC<PathwayDisplayProps> = ({ result, onReset, language }) => {
  const currentStrings = LOCALIZED_STRINGS[language];

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-12">
        <h2 className="text-2xl md:text-3xl font-bold text-slate-800 text-center mb-4">
          {currentStrings.gapAnalysisTitle}
        </h2>
        <div className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
          <p className="text-slate-600 leading-relaxed">{result.gapAnalysis}</p>
        </div>
      </div>
    
      <div>
        <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-teal-500 to-cyan-500 text-transparent bg-clip-text mb-2">
                {result.pathway.pathwayTitle}
            </h1>
            <p className="text-slate-500">{currentStrings.pathwaySubtitle}</p>
        </div>

        <div className="relative ps-8">
            <div className="absolute top-0 bottom-0 left-0 w-0.5 bg-cyan-200" style={{ [language === 'ur' ? 'right' : 'left']: '15px' }}></div>
            <div className="space-y-8">
                {result.pathway.steps.sort((a, b) => a.step - b.step).map((step, index) => (
                    <PathwayStepCard key={index} step={step} language={language} />
                ))}
            </div>
        </div>

        <div className="text-center mt-12">
            <button
                onClick={onReset}
                className="px-8 py-3 bg-slate-700 text-white font-semibold rounded-lg shadow-md hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-opacity-50 transition-transform transform hover:scale-105"
            >
                {currentStrings.startOverButton}
            </button>
        </div>
      </div>
    </div>
  );
};

export default PathwayDisplay;
