import React from 'react';
import { LearningStep, Language } from '../types';
import { LOCALIZED_STRINGS } from '../constants';
import { VideoIcon, ArticleIcon, QuizIcon, InteractiveIcon } from './icons';

interface PathwayStepCardProps {
  step: LearningStep;
  language: Language;
}

const typeIcons: Record<LearningStep['type'], React.ReactNode> = {
  video: <VideoIcon className="h-5 w-5" />,
  article: <ArticleIcon className="h-5 w-5" />,
  quiz: <QuizIcon className="h-5 w-5" />,
  interactive: <InteractiveIcon className="h-5 w-5" />,
};

const typeColors: Record<LearningStep['type'], string> = {
  video: 'bg-red-100 text-red-700',
  article: 'bg-blue-100 text-blue-700',
  quiz: 'bg-yellow-100 text-yellow-800',
  interactive: 'bg-green-100 text-green-700',
};

const PathwayStepCard: React.FC<PathwayStepCardProps> = ({ step, language }) => {
  const { title, description, type, link } = step;
  const currentStrings = LOCALIZED_STRINGS[language];
  const isRtl = language === 'ur';

  return (
    <div className="relative">
      <div
        className={`absolute top-1 w-8 h-8 flex items-center justify-center bg-cyan-500 text-white font-bold rounded-full border-4 border-slate-100 z-10`}
        style={{ [isRtl ? 'right' : 'left']: '-42px' }}
      >
        {step.step}
      </div>
      <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden flex flex-col h-full transform hover:-translate-y-1 transition-transform duration-300 ms-4">
        <div className="p-6 flex-grow">
          <div className="flex justify-between items-start mb-3">
            <div className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-1 text-sm font-semibold rounded-full ${typeColors[type]}`}>
              {typeIcons[type]}
              <span>{currentStrings.resourceType[type]}</span>
            </div>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">{title}</h3>
          <p className="text-slate-600 text-base leading-relaxed">{description}</p>
        </div>
        {link && (
          <div className="px-6 pb-6 pt-2">
            <a
              href={link}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center px-4 py-2 font-semibold text-white bg-slate-700 rounded-lg hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 transition-colors"
            >
              {currentStrings.startLearning}
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ms-2 rtl:ms-0 rtl:me-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default PathwayStepCard;
