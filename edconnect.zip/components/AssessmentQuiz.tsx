import React, { useState } from 'react';
import { Language, AssessmentQuestion, Subject, AssessmentAnswers } from '../types';
import { LOCALIZED_STRINGS } from '../constants';

interface AssessmentQuizProps {
  assessment: AssessmentQuestion[];
  subject: Subject;
  onSubmit: (answers: AssessmentAnswers) => void;
  language: Language;
}

const AssessmentQuiz: React.FC<AssessmentQuizProps> = ({ assessment, subject, onSubmit, language }) => {
  const [answers, setAnswers] = useState<AssessmentAnswers>({});
  const currentStrings = LOCALIZED_STRINGS[language];
  
  const handleAnswerChange = (questionIndex: number, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionIndex]: answer }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(answers);
  };
  
  const allAnswered = Object.keys(answers).length === assessment.length;

  return (
    <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg border border-slate-200">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">{currentStrings.assessmentFor} <span className="text-cyan-600">{subject.name}</span></h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {assessment.map((q, index) => (
          <div key={index} className="border-b border-slate-200 pb-6">
            <p className="text-lg font-semibold text-slate-700 mb-4">
              <span className="text-cyan-500 font-bold me-2">{index + 1}.</span>
              {q.question}
            </p>
            <div className="space-y-3 ps-6">
              {q.options.map((option, optIndex) => (
                <div key={optIndex}>
                  <input
                    type="radio"
                    id={`q${index}-opt${optIndex}`}
                    name={`question-${index}`}
                    value={option}
                    checked={answers[index] === option}
                    onChange={() => handleAnswerChange(index, option)}
                    className="sr-only"
                    required
                  />
                  <label
                    htmlFor={`q${index}-opt${optIndex}`}
                    className={`block w-full p-3 rounded-lg border cursor-pointer transition-all duration-200 ${answers[index] === option ? 'bg-cyan-100 border-cyan-400 text-cyan-800' : 'bg-slate-50 hover:bg-slate-100 border-slate-300'}`}
                  >
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>
        ))}
        <div className="pt-4">
          <button
            type="submit"
            disabled={!allAnswered}
            className="w-full py-3 px-6 text-lg font-semibold text-white bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-lg transition-all transform hover:scale-105"
          >
            {currentStrings.submitAnswers}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AssessmentQuiz;
