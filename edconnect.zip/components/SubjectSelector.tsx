import React, { useState } from 'react';
import { Language, Subject } from '../types';
import { LOCALIZED_STRINGS, SUBJECTS_EN, SUBJECTS_UR } from '../constants';

interface SubjectSelectorProps {
  onSubjectSelect: (subject: Subject) => void;
  language: Language;
}

const SubjectSelector: React.FC<SubjectSelectorProps> = ({ onSubjectSelect, language }) => {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);

  const currentStrings = LOCALIZED_STRINGS[language];
  const subjects = language === 'en' ? SUBJECTS_EN : SUBJECTS_UR;

  const handleSelect = (subject: Subject) => {
    setSelectedSubject(subject);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(selectedSubject){
        onSubjectSelect(selectedSubject);
    }
  }

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg border border-slate-200">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">{currentStrings.subjectTitle}</h2>
        <p className="text-slate-500 mt-2">{currentStrings.subjectSubtitle}</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          {subjects.map((subject) => (
            <div key={subject.id}>
              <input
                type="radio"
                id={`subject-${subject.id}`}
                name="subject"
                value={subject.id}
                checked={selectedSubject?.id === subject.id}
                onChange={() => handleSelect(subject)}
                className="sr-only"
              />
              <label
                htmlFor={`subject-${subject.id}`}
                className={`block w-full text-center p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${selectedSubject?.id === subject.id ? 'bg-cyan-500 text-white border-cyan-500 shadow-md scale-105' : 'bg-slate-50 hover:bg-slate-100 border-slate-300'}`}
              >
                <span className="font-semibold">{subject.name}</span>
              </label>
            </div>
          ))}
        </div>
        <button
          type="submit"
          disabled={!selectedSubject}
          className="w-full py-3 px-6 text-lg font-semibold text-white bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-lg transition-all transform hover:scale-105"
        >
          {currentStrings.startAssessment}
        </button>
      </form>
    </div>
  );
};

export default SubjectSelector;
